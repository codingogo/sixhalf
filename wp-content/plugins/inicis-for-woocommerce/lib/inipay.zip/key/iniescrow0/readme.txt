	
please read this README.TXT file	
	
ZIP file contains following 3 files.	
  - mcert.pem	
  - mpriv.pem	
  - keypass.enc	
	
Copy these 3 files to directory [key/iniescrow0].	
	
Merchant ID   : iniescrow0	
Key Password  : 1111	
Admin Password: 1111	
	
please visit https://iniweb.inicis.com	
for your Merchant Administration.	
This site provides your payment transaction details and account details by calculation period.	
	
You can also log on this site using your Merchant ID(iniescrow0).	
